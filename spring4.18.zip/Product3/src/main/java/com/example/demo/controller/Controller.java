package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Cart;
import com.example.demo.model.Product;
import com.example.demo.repository.CartRepository;
import com.example.demo.repository.ProductRepository;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin("*")
public class Controller {
	@Autowired
	private ProductRepository repository;
	@Autowired
	private CartRepository repository1;
	@PostMapping("/create")
	public Product save(@RequestBody Product product) {
		return repository.save(product);
	}
	@GetMapping("/findAll")
	public List<Product> get(){
		return repository.findAll();
		
	}
	@PostMapping("/add")
	public Cart add(@RequestBody Cart cart) {
		return repository1.save(cart);
	}
	@GetMapping("/getAll")
	public List<Cart> getAll(){
		return repository1.findAll();
	}
	@DeleteMapping("/deleteItem/{id}")
	public  List<Cart> delete(@PathVariable long id)
	{
		Cart cart=repository1.findById(id).orElseThrow(()->new ResourceNotFoundException("not found"+id));
		repository1.delete(cart);
		return repository1.findAllByMobileNumber(cart.getMobileNumber());
		
	}
	@DeleteMapping("/deleteAll/{mobileNumber}")
	public void delete1(@PathVariable String mobileNumber){
		List<Cart> cartItems=repository1.findAllByMobileNumber(mobileNumber);
		for(Cart cart:cartItems) {
			repository1.delete(cart);
			
			
		}
		
	}
	@GetMapping("/grandTotal/{mobileNumber}")
	public long grandTotal(@PathVariable String mobileNumber) {
		List<Cart> cartItems=repository1.findAllByMobileNumber(mobileNumber);
		long total=0;
		for(Cart cart:cartItems) {
			total=total+cart.getPrice();
			
		}
		return total;
	}
	@GetMapping("findAllByMobileNumber/{mobileNumber}")
	public List<Cart> findAllByMobileNumber(@PathVariable String mobileNumber){
		List<Cart> a=repository1.findAllByMobileNumber(mobileNumber);
		return a;
		
	}

}

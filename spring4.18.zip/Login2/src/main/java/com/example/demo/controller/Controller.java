package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.LoginException;
import com.example.demo.model.Login;

import com.example.demo.repository.LoginRepository;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins="*")
public class Controller {
	@Autowired
	private LoginRepository repository;
	@GetMapping("/message")
	public String message() {
		return "hello world!";
	}
	@GetMapping("/findAll")
	public List<Login> findAll(){
		return repository.findAll();
	}
	@PostMapping("/create")
	public Login create(@RequestBody Login login) {
		return repository.save(login);
		
	}
	@GetMapping("/login/{mobileNumber}")
	public Login get(@PathVariable String mobileNumber) {
		Login user=repository.findByMobileNumber(mobileNumber);
		if(user==null) {
			throw new LoginException("not found"+mobileNumber);
			
		}
		else
		{
			return user;
		}
		//"Registration Successful";
	}
	

}

package com.example.demo.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin("*")
public class Controller {
	@Autowired
	private ProductRepository repository;
	@GetMapping("/message")
	private String message() {
		return "hello world!";
		}
	@PostMapping("/create1")
	public Product save(@RequestBody Product product) {
		return repository.save(product);
	}
	@GetMapping("/findAll")
	public List<Product> get(){
		return repository.findAll();
		
	}


	
	  @PostMapping("/create")
	    public ResponseEntity<Product> addProduct(@RequestParam String name, @RequestParam long price, @RequestParam MultipartFile image) {
	        try {
	            Product product = new Product();
	            product.setName(name);
	            product.setPrice(price);
	            product.setImage(image.getBytes());
	            repository.save(product);
	            return ResponseEntity.ok(product);
	        } catch (IOException e) {
	            return ResponseEntity.badRequest().build();
	        }
	    }
	

}

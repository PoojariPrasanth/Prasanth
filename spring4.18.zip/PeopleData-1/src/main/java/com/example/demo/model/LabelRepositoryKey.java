package com.example.demo.model;

import java.io.Serializable;

public class LabelRepositoryKey implements Serializable {
	  private int id;
	  private String mobileNumber;
}
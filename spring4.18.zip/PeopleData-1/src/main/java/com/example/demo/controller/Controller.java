package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.User;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins="*")
public class Controller {
	@Autowired
	private UserRepository repository;
	@PostMapping("/register")
	public User create(@RequestBody User userData) {
		User user=repository.findByMobileNumber(userData.getMobileNumber());
		if(user==null) {
		return repository.save(userData);
		}
		else
		{
			throw new IllegalArgumentException ();
		}
		//"Registration Successful";
	}
	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody LoginController userData){
		User user=repository.findByMobileNumber(userData.getMobileNumber());
		System.out.println(userData.getMobileNumber());
		System.out.println(userData.getPassword());
		if(user.getPassword().equals(userData.getPassword())) {
			return ResponseEntity.ok(user);
		}
		return (ResponseEntity<?>) ResponseEntity.internalServerError();
		
	}
	@GetMapping("/findAll")
	public List<User> getUsers(){
		return repository.findAll();
	}
	@DeleteMapping("/delete/{id}")
	public List<User> delete(@PathVariable int id){
		User user=repository.findById(id).orElseThrow(()->new ResourceNotFoundException("user not present"+id));
		repository.delete(user);
		return repository.findAll();
	}
	@PutMapping("/update/{id}")
	public  List<User> update(@PathVariable int id,@RequestBody User user){
		System.out.println(user.getFirstName());
		System.out.println(user.getLastName());
		System.out.println(user.getMobileNumber());
		System.out.println(user.getPassword());
		System.out.println(id);
		User stu=repository.findById(id).orElseThrow(()->new ResourceNotFoundException("not found"+id));
		stu.setMobileNumber(user.getMobileNumber());
		stu.setFirstName(user.getFirstName());
		stu.setLastName(user.getLastName());
		stu.setPassword(user.getPassword());
		System.out.println(stu.getFirstName());
		System.out.println(stu.getLastName());
		System.out.println(stu.getMobileNumber());
		System.out.println(stu.getPassword());


		
		repository.save(stu);
		return repository.findAll();
		
	}
	@GetMapping("/get/{id}")
	public User get(@PathVariable int id){
		User stu=repository.findById(id).orElseThrow(()->new ResourceNotFoundException("not found"+id));
		return stu;
		
	}
	@DeleteMapping("/deleteAll")
	public void deleteAll(){
		repository.deleteAll();
		System.out.println("deleted");
		
	}
}

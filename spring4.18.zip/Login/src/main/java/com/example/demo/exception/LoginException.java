package com.example.demo.exception;

public class LoginException extends RuntimeException{
	private long serialVersionId=1L;
	public LoginException(String message) {
		super(message);
		
	}

}

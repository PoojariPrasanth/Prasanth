package com.example.demo.exception;

public class ResourcNotFoundException extends RuntimeException{
	private long serialVersionId=1L;
	public ResourcNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}

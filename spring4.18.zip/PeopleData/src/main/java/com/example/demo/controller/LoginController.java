package com.example.demo.controller;

public class LoginController {
	private String mobileNumber;
	private String password;
	public LoginController() {
		// TODO Auto-generated constructor stub
	}
	public LoginController(String mobileNumber, String password) {
		super();
		this.mobileNumber = mobileNumber;
		this.password = password;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "LoginController [mobileNumber=" + mobileNumber + ", password=" + password + "]";
	}
	

}

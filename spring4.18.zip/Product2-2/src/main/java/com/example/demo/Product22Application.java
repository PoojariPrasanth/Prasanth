package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Product22Application {

	public static void main(String[] args) {
		SpringApplication.run(Product22Application.class, args);
	}

}

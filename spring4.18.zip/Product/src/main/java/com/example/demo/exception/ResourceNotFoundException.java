package com.example.demo.exception;

public class ResourceNotFoundException extends RuntimeException{
	private Long serialVersionId=1L;
	public ResourceNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}

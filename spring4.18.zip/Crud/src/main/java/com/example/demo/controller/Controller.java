package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Model;
import com.example.demo.repository.ModelRepository;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins="*")
public class Controller {
	@Autowired
	private ModelRepository repository;
	@GetMapping("/message")
	public String message() {
		return "hello world!";
	}
	
	
	
	@PostMapping("/create")
	public Model create(@RequestBody Model model){
		return repository.save(model);
		
	}
	
	
	@GetMapping("/findAll")
	public List<Model> findAll(){
		return repository.findAll();
	}
	
	@DeleteMapping("/deleteAll")
	public boolean deleteAll() {
		 repository.deleteAll();
		List<Model> a=repository.findAll();
		if(a.size()==0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	@GetMapping("/getById/{id}")
	public Model getById(@PathVariable int id) {
		Model model=repository.findById(id).orElseThrow(()->new ResourceNotFoundException("id not found"+id));
		return model;
		
	}
	
	
	@DeleteMapping("/deleteById/{id}")
	public List<Model> deleteById(@PathVariable int id) {
		Model model=repository.findById(id).orElseThrow(()->new ResourceNotFoundException("not found"+id));
		repository.delete(model);
		return repository.findAll();
		
	}
	
	@PutMapping("/updateById/{id}")
	public ResponseEntity<Model> updateById (@PathVariable int id,@RequestBody Model model) throws NullPointerException{
		Model model1=repository.findById(id).orElseThrow(()->new ResourceNotFoundException("not found"+id));
			if(model.getFirstName().length()!=0) {
				model1.setFirstName(model.getFirstName());
				System.out.println(model.getFirstName());
				}
				if(model.getLastName().length()!=0) {
				model1.setLastName(model.getLastName());
				}
				if(model.getMobileNumber().length()!=0) {
				model1.setMobileNumber(model.getMobileNumber());
				}
		
		
		Model m1=repository.save(model1);
		return ResponseEntity.ok(m1);
	}
}
	
	
	


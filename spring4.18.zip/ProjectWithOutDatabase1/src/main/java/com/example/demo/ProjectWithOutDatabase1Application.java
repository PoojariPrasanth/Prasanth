package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectWithOutDatabase1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectWithOutDatabase1Application.class, args);
	}

}

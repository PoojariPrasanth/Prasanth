package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectWithOutDatabase12Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectWithOutDatabase12Application.class, args);
	}

}
